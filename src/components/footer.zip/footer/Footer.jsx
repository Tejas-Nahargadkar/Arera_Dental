import React from "react";
import "./footer.css";
import logo from "./logo.png";
import { Link } from "react-router-dom";
import { Facebook, Instagram, Youtube } from "react-feather";
export const Footer = () => {
  return (
    <div className="Footer">
      <footer>
        <div className="Row">
          <div className="logo">
            <img src={logo} alt="" />
            <h2>Arera Dental Clinic</h2>
          </div>
          <div className="quicklinks">
            <h3>Quick Links :</h3>
            <ul>
              <li>
                <Link to={"/Home"}>Home</Link>
              </li>
              <li>
                <Link to={"/ContactUs"}>ContactUs</Link>
              </li>
              <li>
                <Link to={"/Procedures"}>Procedures</Link>
              </li>
              <li>
                <Link to={"/BookAppointment"}>Book Appointment</Link>
              </li>
              <li>
                <Link to={"/AboutUs"}>About Us</Link>
              </li>
              <li>
                <Link to={"/Team"}>Our Team</Link>
              </li>
              <li>
                <Link to={"/Feedback"}>Feedback</Link>
              </li>
            </ul>
          </div>
          <div className="contact">
            <h3>Contact Us:</h3>
            <a
              href="https://www.facebook.com/areradentalclinic/"
              target={"_blank"}
              rel="noreferrer"
            >
              <Facebook />
            </a>

            <a
              href="https://youtube.com/c/drswapniljain18"
              target={"_blank"}
              rel="noreferrer"
            >
              <Youtube />
            </a>
            <a
              href="https://instagram.com/arera_dental_care?utm_medium=copy_link"
              target={"_blank"}
              rel="noreferrer"
            >
              <Instagram />
            </a>
            <p>Phone No: +91 90019009</p>
            <p>email : areradentalclinic@gmail.com</p>
            <p className="address">
              1-d, Bhuta Ho,Opp.panchal Steel Ind., Near Reliance, Mogra Road,
              Andheri (east)
            </p>
            <p>+91 90000-00009</p>
          </div>
        </div>
        <hr />
        <div className="Row">
              <h3>Privacy Policy</h3>

              <h3>Terms & Conditions</h3>
          </div>
      </footer>
    </div>
  );
};
