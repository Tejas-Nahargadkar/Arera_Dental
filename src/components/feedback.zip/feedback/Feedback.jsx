import React from "react";
import './feedback.css'
import Feedbackpana from './Feedbackpana.svg'
export default function Feedback() {
    const scriptURL =
    "https://script.google.com/macros/s/AKfycbwryBU0JsThNJRxGZ82PJuxjFtUd35VNtOvodrUDwj6ClcrzXuLw5yW0tGPkRODuZ6D/exec";
  const form = document.forms["FeedbackForm"];

  const HandleSubmit = (e) => {
    e.preventDefault();
    console.log("Clicked");
    let data = new FormData(form);
    console.log(data);
    fetch(scriptURL, { method: "POST", body: data })
      .then((response) => {
        //sendEmail(e);
        console.log("Success!", response);
      })
      .catch((error) => console.error("Error!", error.message));
  };


  return (
    <div className="FeedBackForm">
      <div className="feedbackForm">
        <div className="FeedbackImage">
                <img src={Feedbackpana} alt="" />
          <h1>
            Arera Dental <span className="Mods">Clinic</span>
          </h1>
        </div>
        <div className="Form-1">
          <h1>Give Your Feedback</h1>
          <form name="FeedbackForm" onSubmit= { HandleSubmit } >
            <label for="firstname">Full Name</label>
            <input
              type="text"
              id="name"
              name="fullname"
              placeholder="Your name.."
            />


            <label for="subject">Query</label>
            <textarea
              id="subject"
              name="query"
              placeholder="Write something.."
            ></textarea>

            <input type="submit" value="Submit" />
          </form>
        </div>
      </div>
      
    </div>
  );
}
