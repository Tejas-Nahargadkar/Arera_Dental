import React from 'react'

export default function FloatingButton() {
  return (
    <div >FloatingButton</div>
  )
}
